<a href="{{ $href ?? '#' }}"
   class="btn text-white {{ $class ?? 'd-flex align-items-center justify-content-center gap-2 w-100 w-md-auto px-3 px-md-5 py-3 fs-5 fs-md-5 gift-btn-responsive' }}"
   style="background-color: var(--primary-color); border-right: 3px solid white; border-left: 3px solid white; border-radius: 30px;">
    @if (!empty($icon))
        {!! $icon !!}
    @endif
    <span class="text-center">{{ $text ?? 'Button' }}</span>
</a>
<style>
@media (max-width: 767.98px) {
    .gift-btn-responsive {
        font-size: 0.95rem !important;
        max-width: 320px;
        margin-left: auto;
        margin-right: auto;
    }
}
</style>
